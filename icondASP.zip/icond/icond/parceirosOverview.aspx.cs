﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;

namespace icond
{
    public partial class parceirosOverview : System.Web.UI.Page
    {
        String email = "";
        protected void Page_Load(object sender, EventArgs e)
        {
           email = Session["email"].ToString();
           tb_email.Text = email.ToString();
            if(!IsPostBack){
            string connectionString = @"Data Source=localhost;Database=icond;user ID=root; Password=''";
            using (MySqlConnection cn = new MySqlConnection(connectionString))
            {
                cn.Open();

                using (MySqlCommand cmd = new MySqlCommand("SELECT * FROM parceiros WHERE emailParceiro = '" + email.ToString() + "'", cn))
                {
                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {

                        while (reader.Read())
                        {
                            tb_nome.Text = reader["nomeParceiro"].ToString();
                            tb_email.Text = reader["emailParceiro"].ToString();
                            tb_descricao.Text = reader["descricaoParceiro"].ToString();
                        }

                    }
                }
            }
        }
        }

        protected void update_Click(object sender, EventArgs e)
        {
            string connectionString = @"Data Source=localhost;Database=icond;user ID=root; Password=''";
            using (MySqlConnection cn = new MySqlConnection(connectionString))
            {
                cn.Open();

                using (MySqlCommand cmd = new MySqlCommand("UPDATE parceiros SET nomeParceiro='" + tb_nome.Text.ToString() + "', emailParceiro='" + tb_email.Text.ToString() + "', descricaoParceiro='" + tb_descricao.Text.ToString() + "' where emailParceiro='" + email.ToString() + "'", cn))
                {
                    //tb_descricao.Text = "UPDATE parceiros SET nomeParceiro='" + tb_nome.Text.ToString() + "', emailParceiro='" + tb_email.Text.ToString() + "', descricaoParceiro='" + tb_descricao.Text.ToString() + "' where emailParceiro='" + email.ToString() + "'";
                    cmd.ExecuteNonQuery();
                    Response.Redirect("parceirosOverview.aspx");
                }
            }
        }
    }
}