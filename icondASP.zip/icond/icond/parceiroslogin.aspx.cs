﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;

namespace icond
{
    public partial class parceiros : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        protected void loginParceiros_Click(object sender, EventArgs e)
        {
            string connectionString = @"Data Source=localhost;Database=icond;user ID=root; Password=''";
            using (MySqlConnection cn = new MySqlConnection(connectionString))
            {
                cn.Open();

                using (MySqlCommand cmd = new MySqlCommand("SELECT COUNT(*) FROM parceiros WHERE emailParceiro='" + tb_email.Text.ToString() + "' AND passwordParceiro='" + tb_password.Text.ToString() + "'", cn))
                {
                    String count = cmd.ExecuteScalar().ToString();
                    if(count == "1"){
                        Session["email"] = tb_email.Text;
                        Response.Redirect("parceirosOverview.aspx");
                    }
                }
            }
        }
    }
}