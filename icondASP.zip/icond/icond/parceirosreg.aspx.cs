﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;

namespace icond
{
    public partial class parceirosreg : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        protected void regParceiro_Click(object sender, EventArgs e)
        {
            string connectionString = @"Data Source=localhost;Database=icond;user ID=root; Password=''";
            using (MySqlConnection cn = new MySqlConnection(connectionString))
            {
                cn.Open();

                using (MySqlCommand cmd = new MySqlCommand("INSERT INTO parceiros (nomeParceiro, emailParceiro, passwordParceiro, descricaoParceiro) VALUES ('" + tb_nome.Text.ToString() + "','" + tb_email.Text.ToString() + "','" + tb_password.Text.ToString() + "','" + tb_descricao.Text.ToString() + "')", cn))
                {
                    cmd.ExecuteNonQuery();
                    Response.Redirect("parceiroslogin.aspx");
                }
            }
        }
    }
}